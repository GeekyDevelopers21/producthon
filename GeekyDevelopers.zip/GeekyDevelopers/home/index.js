function DisplayMeOptions() {
	if(document.getElementById('quizContentdisplay').style.display == 'block')
		 document.getElementById('quizContentdisplay').style.display ="none";
	else 
		 document.getElementById('quizContentdisplay').style.display = "block";
 }